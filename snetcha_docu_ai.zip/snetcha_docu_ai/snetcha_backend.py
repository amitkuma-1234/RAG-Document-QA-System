"""
S.N.E.T.C.H DOCU AI — Document Intelligence Chatbot Backend
Supports: PDF, DOCX, TXT, PPT/PPTX, and raw pasted text
"""

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import uvicorn
import os
import re
import io
import tempfile
import numpy as np

# ── Document Parsers ──────────────────────────────────────────────────────────
import fitz  # PyMuPDF — PDF
from docx import Document as DocxDocument
from pptx import Presentation as PptxPresentation

# ── ML / Retrieval ────────────────────────────────────────────────────────────
from sentence_transformers import SentenceTransformer, CrossEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ── LLM (HuggingFace) ────────────────────────────────────────────────────────
from langchain_huggingface import ChatHuggingFace, HuggingFaceEndpoint
from langchain_core.messages import HumanMessage, BaseMessage
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver
from typing import TypedDict, Annotated

# ─────────────────────────────────────────────────────────────────────────────
HF_TOKEN = os.getenv("HF_TOKEN", "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")

app = FastAPI(title="S.N.E.T.C.H DOCU AI", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Global Session State ──────────────────────────────────────────────────────
# One active document per session (extend to multi-session with dict keyed by session_id)
session_store = {}

# ── Models (loaded once at startup) ──────────────────────────────────────────
print("Loading embedding model...")
embed_model = SentenceTransformer("all-mpnet-base-v2")
print("Loading reranker...")
reranker = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")
print("Models ready!\n")

# ── LLM Setup ─────────────────────────────────────────────────────────────────
llm = HuggingFaceEndpoint(
    repo_id="MiniMaxAI/MiniMax-M2.5",
    task="text-generation",
    huggingfacehub_api_token=HF_TOKEN,
    max_new_tokens=1024,
    temperature=0.1,
)
chat_model = ChatHuggingFace(llm=llm)


# ══════════════════════════════════════════════════════════════════════════════
# DOCUMENT PARSERS
# ══════════════════════════════════════════════════════════════════════════════

def parse_pdf(file_bytes: bytes) -> str:
    """Extract text from PDF using PyMuPDF."""
    text_parts = []
    with fitz.open(stream=file_bytes, filetype="pdf") as doc:
        for page in doc:
            text_parts.append(page.get_text())
    return "\n".join(text_parts)


def parse_docx(file_bytes: bytes) -> str:
    """Extract text from DOCX."""
    doc = DocxDocument(io.BytesIO(file_bytes))
    paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    # Also extract tables
    for table in doc.tables:
        for row in table.rows:
            row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
            if row_text:
                paragraphs.append(row_text)
    return "\n".join(paragraphs)


def parse_pptx(file_bytes: bytes) -> str:
    """Extract text from PPTX — all slides, shapes, notes."""
    prs = PptxPresentation(io.BytesIO(file_bytes))
    slide_texts = []
    for i, slide in enumerate(prs.slides, 1):
        parts = [f"[Slide {i}]"]
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text.strip():
                parts.append(shape.text.strip())
        # Speaker notes
        if slide.has_notes_slide:
            notes = slide.notes_slide.notes_text_frame.text.strip()
            if notes:
                parts.append(f"[Notes]: {notes}")
        slide_texts.append("\n".join(parts))
    return "\n\n".join(slide_texts)


def parse_txt(file_bytes: bytes) -> str:
    """Decode plain text, try UTF-8 then fallback."""
    try:
        return file_bytes.decode("utf-8")
    except UnicodeDecodeError:
        return file_bytes.decode("latin-1", errors="replace")


def parse_document(filename: str, file_bytes: bytes) -> str:
    """Route to correct parser based on file extension."""
    ext = filename.rsplit(".", 1)[-1].lower()
    parsers = {
        "pdf":  parse_pdf,
        "docx": parse_docx,
        "doc":  parse_docx,
        "pptx": parse_pptx,
        "ppt":  parse_pptx,
        "txt":  parse_txt,
        "text": parse_txt,
        "md":   parse_txt,
    }
    if ext not in parsers:
        raise ValueError(f"Unsupported file type: .{ext}")
    return parsers[ext](file_bytes)


# ══════════════════════════════════════════════════════════════════════════════
# CHUNKING
# ══════════════════════════════════════════════════════════════════════════════

def sentence_aware_chunks(text: str, max_words=150, overlap_sentences=3) -> List[str]:
    """Split text into overlapping sentence-aware chunks."""
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    sentences = [s.strip() for s in sentences if s.strip()]
    chunks, current_chunk, current_word_count = [], [], 0

    for sentence in sentences:
        word_count = len(sentence.split())
        if current_word_count + word_count > max_words and current_chunk:
            chunks.append(" ".join(current_chunk))
            current_chunk = current_chunk[-overlap_sentences:]
            current_word_count = sum(len(s.split()) for s in current_chunk)
        current_chunk.append(sentence)
        current_word_count += word_count

    if current_chunk:
        chunks.append(" ".join(current_chunk))
    return chunks


def build_index(text: str) -> dict:
    """
    Build full retrieval index for a document text.
    Returns a session data dict with chunks, vectors, tfidf.
    """
    word_count = len(text.split())

    if word_count <= 4000:
        chunks = [text]
        use_full = True
    else:
        chunks = sentence_aware_chunks(text, max_words=150, overlap_sentences=3)
        use_full = False

    # Embed
    chunk_vectors = embed_model.encode(chunks, show_progress_bar=False, normalize_embeddings=True)

    # TF-IDF
    tfidf = TfidfVectorizer(stop_words="english")
    tfidf_matrix = tfidf.fit_transform(chunks)

    return {
        "text": text,
        "chunks": chunks,
        "chunk_vectors": chunk_vectors,
        "tfidf": tfidf,
        "tfidf_matrix": tfidf_matrix,
        "use_full": use_full,
        "word_count": word_count,
    }


# ══════════════════════════════════════════════════════════════════════════════
# RETRIEVAL
# ══════════════════════════════════════════════════════════════════════════════

def retrieve_context(query: str, session_data: dict, top_k=10, final_k=5) -> str:
    """Hybrid semantic + keyword retrieval with cross-encoder reranking."""
    if session_data["use_full"]:
        return session_data["text"]

    chunks       = session_data["chunks"]
    chunk_vectors = session_data["chunk_vectors"]
    tfidf        = session_data["tfidf"]
    tfidf_matrix = session_data["tfidf_matrix"]

    # Semantic
    query_vec = embed_model.encode([query], normalize_embeddings=True)
    semantic_scores = np.dot(chunk_vectors, query_vec.T).flatten()

    # Keyword (TF-IDF)
    query_tfidf = tfidf.transform([query])
    keyword_scores = cosine_similarity(query_tfidf, tfidf_matrix).flatten()

    # Hybrid: 60% semantic + 40% keyword
    hybrid_scores = 0.6 * semantic_scores + 0.4 * keyword_scores
    top_indices   = np.argsort(hybrid_scores)[-top_k:][::-1]
    candidates    = [(idx, chunks[idx]) for idx in top_indices]

    # Rerank
    pairs  = [[query, chunk] for _, chunk in candidates]
    scores = reranker.predict(pairs)
    ranked = sorted(zip(scores, candidates), key=lambda x: x[0], reverse=True)
    top_chunks = [chunk for _, (_, chunk) in ranked[:final_k]]

    return "\n\n".join([f"[Excerpt {i+1}]: {chunk}" for i, chunk in enumerate(top_chunks)])


# ══════════════════════════════════════════════════════════════════════════════
# LANGGRAPH CHAT
# ══════════════════════════════════════════════════════════════════════════════

class DocChat(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]
    session_id: str


def make_graph(session_id: str):
    """Build a LangGraph chatbot graph for a given session."""

    def response_generate(state: DocChat):
        user_query  = state["messages"][-1].content
        sid         = state.get("session_id", session_id)
        session_data = session_store.get(sid)

        if not session_data:
            return {"messages": [HumanMessage(content="No document loaded. Please upload a document first.")]}

        context = retrieve_context(user_query, session_data)

        prompt = f"""You are S.N.E.T.C.H DOCU AI — a precise and intelligent document assistant.

STRICT RULES:
- Answer ONLY from the document excerpts below. Nothing else.
- Give COMPLETE answers — do not cut them short.
- Do NOT add disclaimers, notes, or extra commentary.
- Do NOT say "The document mentions..." or "Based on the document..."
- Do NOT warn about missing info unless you truly cannot find it at all.
- If partially found, give what IS there.
- If completely not found, say only: "Not mentioned in the document."
- Be direct and precise. Start your answer immediately.

--- DOCUMENT CONTENT ---
{context}
------------------------

Question: {user_query}

Answer:"""

        response = chat_model.invoke([HumanMessage(content=prompt)])
        return {"messages": [response]}

    graph = StateGraph(DocChat)
    graph.add_node("response_generate", response_generate)
    graph.add_edge(START, "response_generate")
    graph.add_edge("response_generate", END)

    memory  = MemorySaver()
    chatbot = graph.compile(checkpointer=memory)
    return chatbot


# Per-session chatbot graphs
chatbot_store = {}


def get_or_create_chatbot(session_id: str):
    if session_id not in chatbot_store:
        chatbot_store[session_id] = {
            "graph": make_graph(session_id),
            "config": {"configurable": {"thread_id": session_id}},
        }
    return chatbot_store[session_id]


# ══════════════════════════════════════════════════════════════════════════════
# FASTAPI ROUTES
# ══════════════════════════════════════════════════════════════════════════════

class TextUploadRequest(BaseModel):
    text: str
    session_id: str = "default"
    filename: str = "pasted_text.txt"


class ChatRequest(BaseModel):
    message: str
    session_id: str = "default"


class ChatResponse(BaseModel):
    answer: str
    session_id: str


@app.get("/")
def root():
    return {"status": "S.N.E.T.C.H DOCU AI is running 🚀"}


@app.post("/upload/file")
async def upload_file(
    file: UploadFile = File(...),
    session_id: str = Form(default="default"),
):
    """Upload a PDF, DOCX, PPTX, or TXT file."""
    file_bytes = await file.read()

    try:
        extracted_text = parse_document(file.filename, file_bytes)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Parsing failed: {e}")

    if not extracted_text.strip():
        raise HTTPException(status_code=400, detail="No text could be extracted from the document.")

    # Build retrieval index and store in session
    session_store[session_id] = build_index(extracted_text)

    wc = session_store[session_id]["word_count"]
    num_chunks = len(session_store[session_id]["chunks"])

    return {
        "status": "ready",
        "session_id": session_id,
        "filename": file.filename,
        "word_count": wc,
        "num_chunks": num_chunks,
        "message": f"Document loaded! {wc} words, {num_chunks} chunks ready for Q&A.",
    }


@app.post("/upload/text")
async def upload_text(req: TextUploadRequest):
    """Accept raw pasted text as document."""
    if not req.text.strip():
        raise HTTPException(status_code=400, detail="Empty text provided.")

    session_store[req.session_id] = build_index(req.text)

    wc = session_store[req.session_id]["word_count"]
    num_chunks = len(session_store[req.session_id]["chunks"])

    return {
        "status": "ready",
        "session_id": req.session_id,
        "filename": req.filename,
        "word_count": wc,
        "num_chunks": num_chunks,
        "message": f"Text loaded! {wc} words ready for Q&A.",
    }


@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    """Send a question and get an answer about the uploaded document."""
    if req.session_id not in session_store:
        raise HTTPException(
            status_code=400,
            detail="No document loaded for this session. Please upload a document first.",
        )

    bot = get_or_create_chatbot(req.session_id)

    response = bot["graph"].invoke(
        {
            "messages": [HumanMessage(content=req.message)],
            "session_id": req.session_id,
        },
        bot["config"],
    )

    answer = response["messages"][-1].content
    return ChatResponse(answer=answer, session_id=req.session_id)


@app.delete("/session/{session_id}")
def clear_session(session_id: str):
    """Clear a session (remove uploaded document)."""
    session_store.pop(session_id, None)
    chatbot_store.pop(session_id, None)
    return {"status": "cleared", "session_id": session_id}


@app.get("/session/{session_id}/info")
def session_info(session_id: str):
    """Get info about currently loaded document."""
    if session_id not in session_store:
        return {"loaded": False}
    data = session_store[session_id]
    return {
        "loaded": True,
        "word_count": data["word_count"],
        "num_chunks": len(data["chunks"]),
        "use_full_transcript": data["use_full"],
    }


# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    uvicorn.run("snetcha_backend:app", host="0.0.0.0", port=8000, reload=True)
